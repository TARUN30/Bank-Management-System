import axios from "axios"
import AxiosInstance from "./AxiosInstance"

export default function GetFile(){

    const fetchGoals = async ()=>{
    try{
      const response = await AxiosInstance.get("/goals/getGoals?accountId=9879739721");
      alert(response.data.entity.length)
    }
        catch(error){
            console.log(error)
        }
}
fetchGoals()

    return (
        <>
        <h1>I hate my life.</h1>
        </>
    )
}