import { useState } from "react";
import axios from "axios";
import AxiosInstance from "./AxiosInstance";

function GoalDetails({ goal }) {
  const [amount, setAmount] = useState("");
  const token = localStorage.getItem("token");

  const handleTransaction = async (type) => {
    try {
      await AxiosInstance.post(
        `user/goals/${goal.id}/${type}`,
        { amount },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      alert(`${type} Successful`);
    } catch (error) {
      alert(`${type} Failed`);
    }
  };

  return (
    <div>
      <h2>{goal.description}</h2>
      <p>Target Amount: ${goal.targetAmount}</p>
      <p>Saved Amount: ${goal.savedAmount}</p>
      <p>Period: ${goal.period}</p>

      <input type="number" placeholder="Enter amount" onChange={(e) => setAmount(e.target.value)} required />
      <button onClick={() => handleTransaction("deposit")}>Deposit</button>
      <button onClick={() => handleTransaction("withdraw")}>Withdraw</button>
    </div>
  );
}

export default GoalDetails;
