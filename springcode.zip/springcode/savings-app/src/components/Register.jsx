import { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import Header from "./Header";

function Register() {
  const [user, setUser] = useState({ username: "", email: "", password: "", confirmPassword: "" });
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleChange = (e) => setUser({ ...user, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Check if passwords match before submitting
    if (user.password !== user.confirmPassword) {
      setError("Passwords do not match!");
      return;
    }

    try {
      await axios.post("http://localhost:8096/api/v1/users/register", {
        username: user.username,
        email: user.email,
        password: user.password,
      });

      alert("Registration Successful!");
      navigate("/login");
    } catch (error) {
      alert("Registration Failed");
      console.log(error)
    }
  };

  return (
    <><Header/>
    <div className="login-container">
      <form className="login-form" onSubmit={handleSubmit}>
        <h2>Register</h2>
        <label htmlFor="username">Username</label>
        <input type="text" id="username" name="username" placeholder="username1" onChange={handleChange} required />

        <label htmlFor="email">Email</label>
        <input type="email" id="email" name="email" placeholder="example@gmail.com" onChange={handleChange} required />

        <label htmlFor="password">Password</label>
        <input type="password" id="password" name="password" placeholder="******" onChange={handleChange} required />

        <label htmlFor="confirmPassword">Confirm Password</label>
        <input type="password" id="confirmPassword" name="confirmPassword" placeholder="******" onChange={handleChange} required />

        {error && <p style={{ color: "red" }}>{error}</p>}

        <button type="submit">Register</button>
      </form>
    </div>
    </>
  );
}

export default Register;
