import React, { useState, useEffect } from "react";
import AxiosInstance from "./AxiosInstance";
import "./Dashboard.css";

const Dashboard = () => {
  const [account, setAccount] = useState({});
  const [goals, setGoals] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [showForm, setShowForm] = useState(false);
  const [goalData, setGoalData] = useState({ goalName: "", targetAmount: 0 });

  const pageSize = 5; // Number of goals per page

  useEffect(() => {
    fetchAccountDetails();
    fetchGoals();
  }, []);

  // Fetch account details
  const fetchAccountDetails = async () => {
    try {
      let account = localStorage.getItem("account");
      const response = await AxiosInstance.get("/accounts/getAccount", {
        params: { accountNumber: parseInt(account, 10) },
      });
      setAccount(response.data);
    } catch (error) {
      console.error("Error fetching account details", error);
    }
  };

  // Fetch financial goals (without backend pagination)
  const fetchGoals = async () => {
    try {
      let account = localStorage.getItem("account");
      const response = await AxiosInstance.get(
        `/goals/getGoals?accountId=${parseInt(account, 10)}`
      );

      if (Array.isArray(response.data.entity)) {
        setGoals(response.data.entity);
      } else {
        setGoals([]);
      }
    } catch (error) {
      console.error("Error fetching goals", error);
    }
  };

  // Handle input changes
  const handleInputChange = (e) => {
    setGoalData({ ...goalData, [e.target.name]: e.target.value });
  };

  // Handle goal submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const formattedPeriod = goalData.period
        ? new Date(goalData.period).toISOString().slice(0, 19)
        : null;
      await AxiosInstance.post("/goals/createGoal", {
        accountNumber: account.accountNumber,
        ...goalData,
        period: formattedPeriod,
      });
      alert("Goal created successfully!");
      setShowForm(false);
      fetchGoals();
    } catch (error) {
      console.error("Error creating goal", error);
      alert("Failed to create goal. Please try again.");
    }
  };

  // Pagination logic
  const indexOfLastGoal = currentPage * pageSize;
  const indexOfFirstGoal = indexOfLastGoal - pageSize;
  const currentGoals = goals.slice(indexOfFirstGoal, indexOfLastGoal);
  const totalPages = Math.ceil(goals.length / pageSize);

  return (
    <div className="dashboard-container">
      <h2>Account Details</h2>
      {account?.accountNumber ? (
        <div className="account-details">
          <p>
            <strong>Account Number:</strong> {account.accountNumber}
          </p>
          <p>
            <strong>Balance:</strong> ${account.balance?.toFixed(2)}
          </p>
          <p>
            <strong>Created On:</strong> {account.createdOn}
          </p>
          <button onClick={() => setShowForm(true)}>Create Goal</button>
          {showForm && <button onClick={() => setShowForm(false)}>Cancel</button>}
        </div>
      ) : (
        <p>Loading account details...</p>
      )}

      {/* Goal Creation Form */}
      {showForm && (
        <div className="goal-form">
          <h3>Create a New Goal</h3>
          <form onSubmit={handleSubmit}>
            <label>
              Account Number:
              <input type="text" value={account?.accountNumber} disabled />
            </label>
            <br />
            <label>
              Goal Name:
              <input type="text" name="goalName" value={goalData.goalName} onChange={handleInputChange} required />
            </label>
            <br />
            <label>
              Target Amount:
              <input type="number" name="targetAmount" value={goalData.targetAmount} onChange={handleInputChange} required />
            </label>
            <br />
            <button type="submit">Submit</button>
          </form>
        </div>
      )}

      <h2>Financial Goals</h2>
      {currentGoals.length > 0 ? (
        <div>
          {currentGoals.map((goal, index) => (
            <div key={index} className="goal-item">
              <p>
                <strong>Goal Name:</strong> {goal.goalName}
              </p>
              <p>
                <strong>Target Amount:</strong> ${goal.targetAmount.toFixed(2)}
              </p>
              <p>
                <strong>Saved Amount:</strong> ${goal.savedAmount ? goal.savedAmount.toFixed(2) : "0.00"}
              </p>
              <p>
                <strong>Period:</strong> {goal.period ? new Date(goal.period).toLocaleDateString() : "N/A"}
              </p>
            </div>
          ))}

          {/* Pagination Controls */}
          <div className="pagination">
            <button disabled={currentPage === 1} onClick={() => setCurrentPage((prev) => prev - 1)}>
              Previous
            </button>
            <span>
              Page {currentPage} of {totalPages}
            </span>
            <button disabled={currentPage === totalPages} onClick={() => setCurrentPage((prev) => prev + 1)}>
              Next
            </button>
          </div>
        </div>
      ) : (
        <p>No financial goals found.</p>
      )}
    </div>
  );
};

export default Dashboard;
