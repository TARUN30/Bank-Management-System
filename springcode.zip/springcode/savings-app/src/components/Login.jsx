import { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import "./Login.css";
import Header from "./Header";

function Login() {
  const [credentials, setCredentials] = useState({ username: "", email: "", password: "" });
  const navigate = useNavigate();

  const handleChange = (e) => setCredentials({ ...credentials, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post("http://localhost:8096/api/v1/users/login", credentials);
      localStorage.setItem("token", res.data.entity.token);
      localStorage.setItem("account", res.data.entity.accountNumber)
      navigate("/dashboard");
    } catch (error) {
      alert("Login Failed");
    }
  };

  return (
    <><Header/>
    <div className="login-container">
      <form className="login-form" onSubmit={handleSubmit}>
        <h2>Login</h2>
        <label htmlFor="username">Username</label>
        <input type="text" id="username" name="username" placeholder="username1" onChange={handleChange} required />
      <br />
        <label htmlFor="email">Email</label>
        <input type="email" id="email" name="email" placeholder="example@gmail.com" onChange={handleChange} required />
      <br />
        <label htmlFor="password">Password</label>
        <input type="password" id="password" name="password" placeholder="******" onChange={handleChange} required />
      <br />
        <button type="submit">Login</button>
      </form>
    </div>
    </>
  );
}

export default Login;
