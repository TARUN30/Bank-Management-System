function AdminDashboard() {
    return (
      <div>
        <h2>Admin Dashboard</h2>
        <ul>
          <li>View All Users</li>
          <li>Manage Transactions</li>
          <li>Generate Reports</li>
        </ul>
      </div>
    );
  }
  
  export default AdminDashboard;
  