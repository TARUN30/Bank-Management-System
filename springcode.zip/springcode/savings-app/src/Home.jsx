import { Link } from "react-router-dom";
import "./Home.css"

function Home() {
  return (
    <div className="containerHome">
      <h1 >Welcome to the Savings App</h1>
      <p>Track and manage your savings efficiently.</p>

      <Link to="/login">
        <button>Login</button>
      </Link>

      <Link to="/register">
        <button>Register</button>
      </Link>
    </div>
  );
}

export default Home;
