package com.example.savingsApplication.Transaction;

import com.example.savingsApplication.Account.Account;
import com.example.savingsApplication.Account.AccountRepo;
import com.example.savingsApplication.Goal.Goal;
import com.example.savingsApplication.Goal.GoalRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

class TransactionServiceTest {
    @Mock
    private TransactionRepo transactionRepo;

    @Mock
    private AccountRepo accountRepo;

    @Mock
    private GoalRepo goalRepo;

    @InjectMocks
    private TransactionService transactionService;

    private Goal goal;
    private Account account;
    private TransactionDTO depositDTO;
    private TransactionDTO withdrawDTO;
    private Transaction transaction;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        account = new Account();
        account.setAccountNumber(123456L);
        account.setBalance(1000.00);

        goal = new Goal();
        goal.setGoalName("New Car");
        goal.setSavedAmount(500.00);
        goal.setAccount(account);

        depositDTO = TransactionDTO.builder()
                .goalName("New Car")
                .amount(200.00)
                .tranType(TranType.DEPOSIT)
                .build();


        withdrawDTO = TransactionDTO.builder()
                .goalName("New Car")
                .amount(100.00)
                .tranType(TranType.WITHDRAW)
                .build();

        transaction = Transaction.builder()
                .amount(200.00)
                .createdOn(LocalDateTime.now())
                .tranType(TranType.DEPOSIT)
                .goal(goal)
                .build();
    }

    @Test
    void testDeposit_Success() {
        when(goalRepo.findByGoalName("New Car")).thenReturn(Optional.of(goal));
        when(accountRepo.findByAccountNumber(123456L)).thenReturn(Optional.of(account));
        when(transactionRepo.save(any(Transaction.class))).thenReturn(transaction);

        Transaction savedTransaction = transactionService.deposit(depositDTO);

        assertEquals(700.00, goal.getSavedAmount());
        assertEquals(1200.00, account.getBalance());
    }

    @Test
    void testWithdraw_Success() {
        when(goalRepo.findByGoalName("New Car")).thenReturn(Optional.of(goal));
        when(accountRepo.findByAccountNumber(123456L)).thenReturn(Optional.of(account));
        when(transactionRepo.save(any(Transaction.class))).thenReturn(transaction);

        Transaction savedTransaction = transactionService.withdraw(withdrawDTO);

        assertEquals(400.00, goal.getSavedAmount());
        assertEquals(900.00, account.getBalance());
    }

    @Test
    void testWithdraw_Failure_InsufficientFunds() {
        withdrawDTO.setAmount(600.00); // More than saved amount

        when(goalRepo.findByGoalName("New Car")).thenReturn(Optional.of(goal));
        when(accountRepo.findByAccountNumber(123456L)).thenReturn(Optional.of(account));

        Exception exception = assertThrows(IllegalArgumentException.class, () -> transactionService.withdraw(withdrawDTO));

        assertEquals("Insufficient saved amount for withdrawal.", exception.getMessage());
    }

    @Test
    void testGetAllTransactions() {
        when(transactionRepo.findAll()).thenReturn(List.of(transaction));

        List<Transaction> transactions = transactionService.getAllTransactions("New Car");

        assertEquals(1, transactions.size());
        assertEquals("New Car", transactions.get(0).getGoal().getGoalName());

    }

    //New Tests

    /**
     * Test deposit when GoalDTO is null
     */
    @Test
    void testDeposit_NullTransactionDTO() {
        when(goalRepo.findByGoalName("Nonexistent Goal")).thenReturn(Optional.empty());
        Exception exception = assertThrows(IllegalArgumentException.class, () -> transactionService.deposit(null));

        assertEquals("TransactionDTO(deposit) should not be null.", exception.getMessage());  // Expect failure in repo lookup
    }

    /**
     * Test deposit when Goal name is empty
     */
    @Test
    void testDeposit_EmptyGoalName() {
        depositDTO.setGoalName("");
        Exception exception = assertThrows(IllegalArgumentException.class, () -> transactionService.deposit(depositDTO));
        assertEquals("Goal Name in TransactionDTO should not be null.", exception.getMessage());  // Goal name missing
    }

    /**
     * Test deposit when Goal is not found
     */
    @Test
    void testDeposit_GoalNotFound() {
        when(goalRepo.findByGoalName(anyString())).thenReturn(Optional.empty());

        Exception exception = assertThrows(IllegalArgumentException.class, () -> transactionService.deposit(depositDTO));
        assertEquals("Goal not found.", exception.getMessage());
    }

    /**
     * Test deposit when Account is not found
     */
    @Test
    void testDeposit_AccountNotFound() {
        when(goalRepo.findByGoalName(withdrawDTO.getGoalName())).thenReturn(Optional.of(goal));
        when(accountRepo.findByAccountNumber(goal.getAccount().getAccountNumber())).thenReturn(Optional.empty());

        Exception exception = assertThrows(IllegalArgumentException.class, () -> transactionService.deposit(depositDTO));
        assertEquals("Account not found.", exception.getMessage());
    }

    /**
     * Test withdraw when GoalDTO is null
     */
    @Test
    void testWithdraw_NullTransactionDTO() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> transactionService.withdraw(null));
        assertEquals("TransactionDTO(withdrawal) should not be null.", exception.getMessage());
    }

    /**
     * Test withdraw when Goal is not found
     */
    @Test
    void testWithdraw_GoalNotFound() {
        when(goalRepo.findByGoalName(anyString())).thenReturn(Optional.empty());

        Exception exception = assertThrows(IllegalArgumentException.class, () -> transactionService.withdraw(withdrawDTO));
        assertEquals("Goal not found", exception.getMessage());
    }

    /**
     * Test withdraw when Account is not found
     */
    @Test
    void testWithdraw_AccountNotFound() {
        when(goalRepo.findByGoalName(withdrawDTO.getGoalName())).thenReturn(Optional.of(goal));
        when(accountRepo.findByAccountNumber(goal.getAccount().getAccountNumber())).thenReturn(Optional.empty());

        Exception exception = assertThrows(IllegalArgumentException.class, () -> transactionService.withdraw(withdrawDTO));
        assertEquals("Account not found.", exception.getMessage());
    }


    /**
     * Test getAllTransactions when Goal name is null
     */
    @Test
    void testGetAllTransactions_NullGoalName() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> transactionService.getAllTransactions(null));

        assertEquals("Goal Name should not be null", exception.getMessage());
    }


    /**
     * Test getAllTransactions when no transactions exist
     */
    @Test
    void testGetAllTransactions_NoTransactionsFound() {
        when(transactionRepo.findAll()).thenReturn(Collections.emptyList());

        assertTrue(transactionService.getAllTransactions("Car Savings").isEmpty());
    }
}
