package com.example.savingsApplication.Goal;

import com.example.savingsApplication.Account.Account;
import com.example.savingsApplication.Account.AccountRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class GoalServiceTest {
    @Mock
    private GoalRepo goalRepo;

    @Mock
    private AccountRepo accountRepo;

    @InjectMocks
    private GoalService goalService;

    private Account account;
    private Goal goal, goal1, goal2;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        account = Account.builder()
                .id(1L)
                .accountNumber(1234567890L)
                .goals(Set.of())
                .build();

        goal = Goal.builder()
                .goalName("Buy a Car")
                .targetAmount(10000.0)
                .savedAmount(2000.0)
                .period(LocalDateTime.now().plusMonths(3))
                .build();
        goal.setAccount(account);
        goal1 = Goal.builder()
                .id(1L)
                .goalName("Car Fund")
                .targetAmount(10000)
                .savedAmount(2000)
                .period(LocalDateTime.now().plusMonths(6))
                .build();
        goal1.setAccount(account);
        goal2 = Goal.builder()
                .id(2L)
                .goalName("Vacation Fund")
                .targetAmount(5000)
                .savedAmount(1000)
                .period(LocalDateTime.now().plusMonths(3))
                .build();
        goal2.setAccount(account);
    }

    /**
     * Test creating a goal successfully.
     */
    @Test
    void testCreateGoal_Success() {
        GoalDTO goalDTO = GoalDTO.builder()
                .goalName("Buy a Car")
                .targetAmount(10000.0)
                .accountNumber( 1234567890L)
                .period(LocalDateTime.now().plusMonths(3))
                .build();

        when(accountRepo.findByAccountNumber(1234567890L)).thenReturn(Optional.of(account));
        when(goalRepo.save(any(Goal.class))).thenReturn(goal);
        when(accountRepo.save(any(Account.class))).thenReturn(account);

        GoalResponse response = goalService.createGoal(goalDTO);


        assertEquals("Buy a Car", response.getGoalName());
        assertEquals(10000.0, response.getTargetAmount());
        assertEquals(goalDTO.getPeriod().truncatedTo(ChronoUnit.SECONDS), response.getPeriod().truncatedTo(ChronoUnit.SECONDS));

    }

    /**
     * Test that creating a goal fails if the account does not exist.
     */
    @Test
    void testCreateGoal_AccountNotFound() {
        GoalDTO goalDTO = GoalDTO.builder()
                .goalName("Buy a Car")
                .targetAmount(10000.0)
                .accountNumber( 1234567890L)
                .build();

        when(accountRepo.findByAccountNumber(9999999999L)).thenReturn(Optional.empty());

        Exception exception = assertThrows(IllegalArgumentException.class, () ->
                goalService.createGoal(goalDTO));

        assertEquals("Account not found.", exception.getMessage());
    }

    /**
     * Test retrieving a goal successfully.
     */
    @Test
    void testGetGoal_Success() {
        when(goalRepo.findByGoalName("Buy a Car")).thenReturn(Optional.of(goal));

        Goal result = goalService.getGoal("Buy a Car");

        assertNotNull(result);
        assertEquals("Buy a Car", result.getGoalName());

    }

    /**
     * Test retrieving a goal fails when the goal does not exist.
     */
    @Test
    void testGetGoal_NotFound() {
        when(goalRepo.findByGoalName("Non-Existent Goal")).thenReturn(Optional.empty());

        Exception exception = assertThrows(IllegalArgumentException.class, () ->
                goalService.getGoal("Non-Existent Goal"));

        assertEquals("Goal does not exist", exception.getMessage());

    }

    //New TestCases

    /**
     * Test retrieving a list of goals.
     */
    @Test
    void testGetGoalList_Success() {
        Long accountNumber = 1234567890L;

        when(accountRepo.findByAccountNumber(accountNumber)).thenReturn(Optional.of(account));
        when(goalRepo.findByAccount_Id(account.getId())).thenReturn(Arrays.asList(goal1, goal2));

        List<GoalResponse> goals = goalService.getGoalList(accountNumber);

        assertNotNull(goals);
        assertEquals(2, goals.size());
        assertEquals("Car Fund", goals.get(0).getGoalName());
        assertEquals(10000, goals.get(0).getTargetAmount());
        assertEquals(2000, goals.get(0).getSavedAmount());

        assertEquals("Vacation Fund", goals.get(1).getGoalName());
        assertEquals(5000, goals.get(1).getTargetAmount());
        assertEquals(1000, goals.get(1).getSavedAmount());



    }

    /**
     * Test retrieving an empty list.
     */
    @Test
    void testGetGoalList_Empty() {
        Long accountNumber = 1234567890L;
        when(accountRepo.findByAccountNumber(accountNumber)).thenReturn(Optional.of(account));
        when(goalRepo.findByAccount_Id(account.getId())).thenReturn(Collections.emptyList());

        List<GoalResponse> goals = goalService.getGoalList(accountNumber);

        assertNotNull(goals);
        assertTrue(goals.isEmpty());
    }

    /**
     * Test case for getGoalList() when account is not found
     */
    @Test
    void testGetGoalList_AccountNotFound() {
        when(accountRepo.findByAccountNumber(12334556999L)).thenReturn(Optional.empty());

        Exception exception = assertThrows(IllegalArgumentException.class, () -> goalService.getGoalList(12334556999L));

        assertEquals("Account not found.", exception.getMessage());
    }
    /**
     * Test deleting a goal by setting the delete flag.
     */
    @Test
    void testDeleteGoal_Success() {
        when(goalRepo.findByGoalName("Buy a Car")).thenReturn(Optional.of(goal));

        goalService.delete("Buy a Car");

        assertTrue(goal.isDeleteFlag());

    }

    /**
     * Test deleting a goal fails when the goal is not found.
     */
    @Test
    void testDeleteGoal_NotFound() {
        when(goalRepo.findByGoalName("Non-Existent Goal")).thenReturn(Optional.empty());

        Exception exception = assertThrows(IllegalArgumentException.class, () ->
                goalService.delete("Non-Existent Goal"));

        assertEquals("Goal not found", exception.getMessage());

    }


    /**
     * Test case for findByAccountNumber()
     */
    @Test
    void testFindByAccountNumber_Success() {
        List<Goal> goals = Arrays.asList(goal);
        Page<Goal> goalPage = new PageImpl<>(goals);
        Pageable pageable = PageRequest.of(0, 10);

        when(accountRepo.findByAccountNumber(12334556999L)).thenReturn(Optional.of(account));
        when(goalRepo.findByAccount_Id(account.getId(), pageable)).thenReturn(goalPage);

        Page<Goal> result = goalService.findByAccountNumber(12334556999L, pageable);

        assertNotNull(result);
        assertEquals(1, result.getTotalElements());
        assertEquals("Buy a Car", result.getContent().get(0).getGoalName());
    }

    /**
     * Test case for findByAccountNumber() when account is not found
     */
    @Test
    void testFindByAccountNumber_AccountNotFound() {
        Pageable pageable = PageRequest.of(0, 10);

        when(accountRepo.findByAccountNumber(993455543922L)).thenReturn(Optional.empty());

        Exception exception = assertThrows(IllegalArgumentException.class, () -> goalService.findByAccountNumber(93455543922L, pageable));

        assertEquals("Account not found.", exception.getMessage());
    }

    /**
     * Test to ensure a goal is updated successfully
     **/
    @Test
    void testUpdateGoal_Success() {
        // Arrange
        GoalDTO goalDTO = GoalDTO.builder()
                .accountNumber(123456L)
                .goalName("Buy Car")
                .targetAmount(120000 )
                .build();

        when(goalRepo.findByGoalName("Buy Car")).thenReturn(Optional.of(goal));  // Mocking DB lookup
        when(goalRepo.save(any(Goal.class))).thenReturn(goal);  // Mocking DB save

        // Act
        Goal updatedGoal = goalService.updateGoal(goalDTO);

        // Assert
        assertNotNull(updatedGoal);
        assertEquals(120000, updatedGoal.getTargetAmount());
        verify(goalRepo, times(1)).findByGoalName("Buy Car");  // Ensure DB lookup happens
        verify(goalRepo, times(1)).save(goal);  // Ensure save happens
    }

    /**
     * Test to ensure an error is thrown when a goal does not exist
     **/

    @Test
    void testUpdateGoal_GoalNotFound() {
        // Arrange
        GoalDTO goalDTO = GoalDTO.builder()
                .accountNumber(123456L)
                .goalName("Nonexistent Goal")
                .targetAmount(120000 )
                .build();

        when(goalRepo.findByGoalName("Nonexistent Goal")).thenReturn(Optional.empty());  // Simulate missing goal

        // Act & Assert
        Exception exception = assertThrows(IllegalArgumentException.class, () -> goalService.updateGoal(goalDTO));
        assertEquals("Goal not found", exception.getMessage());

        verify(goalRepo, times(1)).findByGoalName("Nonexistent Goal");  // Ensure DB lookup was attempted
        verify(goalRepo, never()).save(any(Goal.class));  // Ensure no save happens when goal not found
    }

    /**
     * Test to ensure an error is thrown when the goalDTO is null
     **/
    @Test
    public void testWhenGoalDTOIsNullInCreateGoal(){
        GoalDTO goalDTO = null;

        Exception e =assertThrows(IllegalArgumentException.class,
                ()-> goalService.createGoal(goalDTO));

        assertEquals("GoalDTO should not be null", e.getMessage());
    }

    /**
     * Test to ensure an error is thrown when the account Number is null
     **/
    @Test
    public void testWhenAccountNumberIsNullInGetGoalList(){
        Long accountNumber = null;

        Exception e =assertThrows(IllegalArgumentException.class,
                ()-> goalService.getGoalList(accountNumber));

        assertEquals("Account Number should not be null", e.getMessage());
    }

    /**
     * Test to ensure an error is thrown when the account Number is less than 10 digits
     **/
    @Test
    public void testWhenAccountNumberIsLessThan10DigitsInGoalList(){
        Long accountNumber = 12344L;

        Exception e =assertThrows(IllegalArgumentException.class,
                ()-> goalService.getGoalList(accountNumber));

        assertEquals("Account Number should have more than 10 digits", e.getMessage());

    }

    /**
     * Test to ensure an error is thrown when the goal Name is null
     */
    @Test
    public void testWhenGoalNameIsNullInGetGoal(){
        String goalName = null;

        Exception e =assertThrows(IllegalArgumentException.class,
                ()-> goalService.getGoal(goalName));

        assertEquals("Goal Name should not be null", e.getMessage());
    }

    /**
     * Test to ensure an error is thrown when the goalDTO is null
     **/
    @Test
    public void testWhenGoalDTOIsNullInUpdateGoal(){
        GoalDTO goalDTO = null;

        Exception e =assertThrows(IllegalArgumentException.class,
                ()-> goalService.updateGoal(goalDTO));

        assertEquals("GoalDTO should not be null", e.getMessage());
    }

    /**
     * Test to ensure an error is thrown when the goal Name is null
     **/
    @Test
    public void testWhenGoalNameIsNullInDeleteMethod(){
        String goalName = null;

        Exception e =assertThrows(IllegalArgumentException.class,
                ()-> goalService.delete(goalName));

        assertEquals("Goal Name should not be null", e.getMessage());
    }

    /**
     * Test to ensure an error is thrown when the account Number is null
     **/
    @Test
    public void testWhenAccountNumberIsNullInFindByAccountNumber(){
        Long accountNumber = null;
        Pageable pageable = PageRequest.of(0, 10);

        Exception e =assertThrows(IllegalArgumentException.class,
                ()-> goalService.findByAccountNumber(accountNumber, pageable));

        assertEquals("Account Number should not be null", e.getMessage());
    }

    /**
     * Test to ensure an error is thrown when the account Number is less than 10 digits
     **/
    @Test
    public void testWhenAccountNumberIsLessThan10DigitsInFindByAccountNumber(){
        Long accountNumber = 12344L;
        Pageable pageable = PageRequest.of(0, 10);

        Exception e =assertThrows(IllegalArgumentException.class,
                ()-> goalService.findByAccountNumber(accountNumber, pageable));

        assertEquals("Account Number should have more than 10 digits", e.getMessage());

    }

    /**
     * Test to ensure an error is thrown when the page size and number is null
     **/
    @Test
    public void testWhenPageableIsNullInFindByAccountNumber(){
        Long accountNumber = 23447778874L;
        Pageable pageable = null;

        Exception e =assertThrows(IllegalArgumentException.class,
                ()-> goalService.findByAccountNumber(accountNumber, pageable));

        assertEquals("Pageable(page number and page size) should not be null", e.getMessage());
    }

}