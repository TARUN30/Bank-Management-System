package com.example.savingsApplication.Account;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

class AccountServiceTest {

    @Mock
    private AccountRepo accountRepo;

    @InjectMocks
    private AccountService accountService;

    private Account account;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        account = Account.builder()
                .accountNumber(1234567890L)
                .balance(5000.0)
                .createdOn(LocalDateTime.now())
                .build();

    }

    /**
     * Test for retrieving an account successfully.
     */
    @Test
    void testGetAccount_Success() {
        when(accountRepo.findByAccountNumber(1234567890L)).thenReturn(Optional.of(account));

        AccountResponse response = accountService.getAccount(1234567890L);

        assertEquals(1234567890L, response.getAccountNumber());
        assertEquals(5000.0, response.getBalance());
        assertNotNull(response.getCreatedOn());
    }

    /**
     * Test for account not found scenario.
     */
    @Test
    void testGetAccount_AccountNotFound() {
        when(accountRepo.findByAccountNumber(9999999999L)).thenReturn(Optional.empty());

        Exception e = assertThrows(IllegalArgumentException.class, () -> accountService.getAccount(9999999999L));

        assertEquals("Account not found.",e.getMessage());
    }

    /**
     * Test to verify that all accounts are retrieved successfully.
     */
    @Test
    void testGetAllAccounts_Success() {
        Account account1 = Account.builder()
                .accountNumber(1234567890L)
                .balance(5000.0)
                .createdOn(LocalDateTime.now())
                .build();

        Account account2 = Account.builder()
                .accountNumber(9876543210L)
                .balance(3000.0)
                .createdOn(LocalDateTime.now())
                .build();
        when(accountRepo.findAll()).thenReturn(Arrays.asList(account1, account2));

        List<AccountResponse> accounts = accountService.getAllAccounts();


        assertEquals(1234567890L, accounts.get(0).getAccountNumber());
        assertEquals(5000.0, accounts.get(0).getBalance());

        assertEquals(9876543210L, accounts.get(1).getAccountNumber());
        assertEquals(3000.0, accounts.get(1).getBalance());


    }

    /**
     * Test to verify that an empty list is returned when no accounts exist.
     */
    @Test
    void testGetAllAccounts_EmptyList() {
        when(accountRepo.findAll()).thenReturn(List.of());

        List<AccountResponse> accounts = accountService.getAllAccounts();

        assertTrue(accounts.isEmpty());


    }
    //New Tests

    /**
     * Test to ensure an error is thrown when the account Number is null
     **/
    @Test
    public void testWhenAccountNumberIsNull() {
        // Arrange: Set up a null account number
        Long accountNumber = null;

        // Act & Assert: Expect an IllegalArgumentException when calling getAccount with a null account number
        Exception e = assertThrows(IllegalArgumentException.class,
                () -> accountService.getAccount(accountNumber));

        // Verify: Ensure the correct exception message is returned
        assertEquals("Account Number should not be null", e.getMessage());
    }

    /**
     * Test to ensure an error is thrown when the account Number is less than 10 numbers
     **/
    @Test
    public void testWhenAccountNumberIsLessThan10Digits() {
        // Arrange: Set up an account number with fewer than 10 digits
        Long accountNumber = 12344L;

        // Act & Assert: Expect an IllegalArgumentException when calling getAccount with an invalid account number
        Exception e = assertThrows(IllegalArgumentException.class,
                () -> accountService.getAccount(accountNumber));

        // Verify: Ensure the correct exception message is returned
        assertEquals("Account Number should have more than 10 digits", e.getMessage());
    }

}