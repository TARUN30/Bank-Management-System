package com.example.savingsApplication;

import com.example.savingsApplication.User.UserRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class UserInputValidatorTest {

    private UserRepo userRepo;
    private UserInputValidator userInputValidator;

    @BeforeEach
    public void setUp() {
        userRepo = mock(UserRepo.class); // Mocking UserRepo
        userInputValidator = new UserInputValidator(userRepo);
    }

    @Test
    public void testValidateEmailUnique() {
        String email = "useremail@gmail.com";

        when(userRepo.existsByEmail(email)).thenReturn(true);

        Exception e = assertThrows(IllegalStateException.class, ()->{
            userInputValidator.validateEmailUnique(email);
        });

        assertEquals("Email already exists", e.getMessage());
    }

    @Test
    void testValidateEmailNotNull() {
        String email = "";

        Exception e = assertThrows(IllegalArgumentException.class, ()->
                userInputValidator.validateEmailNotNull(email));

        assertEquals("Email should not be null or empty", e.getMessage());

    }

    @Test
    void validateEmailLength() {
        // Arrange
        String longEmail = "longemailaddresslongemailaddresslongaddress@example.com"; // More than 15 characters

        // Act & Assert
        Exception exception = assertThrows(IllegalArgumentException.class,
                () -> userInputValidator.validateEmailLength(longEmail));

        assertEquals("Email should not exceed 30 characters.", exception.getMessage());
    }

    @Test
    void isValidEmail() {
        assertTrue(userInputValidator.isValidEmail("valid@example.com"));
    }

    @Test
    void testValidatePasswordMinLength() {
        String password = "Min4,";

        assertThrows(IllegalArgumentException.class, ()->{
           userInputValidator.validatePasswordMinLength(password);
        });
    }

    @Test
    void testValidatePasswordMaxLength() {
        String password = "LongestPassword123#";

        Exception e = assertThrows(IllegalArgumentException.class,
                ()-> userInputValidator.validatePasswordMaxLength(password));

        assertEquals("Password should not exceed 15 characters.", e.getMessage());
    }

    @Test
    void testValidatePasswordNotNull(){
        String password = "  ";

        Exception e = assertThrows(IllegalArgumentException.class,
                ()-> userInputValidator.validatePasswordNotNull(password), "Password is not null.");

        assertEquals("Password should not be null.", e.getMessage());
    }

    @Test
    void testAtleastOneSymbolInPassword(){
        String password = "Securepass4";

        Exception e =assertThrows(IllegalArgumentException.class,
                ()-> userInputValidator.validateSymbolInPassword(password), "Password has atleast one symbol.");

        assertEquals("Password should have atleast one symbol.", e.getMessage());
    }

    @Test
    void testValidateNumberInPassword(){
        String password = "Userpass$";

        Exception e = assertThrows(IllegalArgumentException.class,
                ()-> userInputValidator.validateNumberInPassword(password), "Password has atleast one number.");

        assertEquals("Password should have atleast one number.", e.getMessage());
    }

    @Test
    void testValidateUpperCaseLetterInPassword(){
        String password = "userpass$";

        Exception e = assertThrows(IllegalArgumentException.class,
                ()-> userInputValidator.validateUppercaseLetterInPassword(password), "Password has atleast one uppercase letter.");

        assertEquals("Password should have atleast one uppercase letter.", e.getMessage());
    }

    @Test
    void testValidateUsernameUnique(){
        String username = "Akash";

        when(userRepo.existsByUsername(username)).thenReturn(true);

        Exception e = assertThrows(IllegalArgumentException.class,
                ()-> userInputValidator.validateUsernameUnique(username), "Username is unique.");

        assertEquals("Username already exists.", e.getMessage());
    }

    @Test
    void testValidUsernameMinLength(){
        String username = "user";

        Exception e = assertThrows( IllegalArgumentException.class,
                ()->userInputValidator.validateUsernameMinLength(username), "Username length exceeds 5 characters.");

        assertEquals("Username length must be 5 characters minimum.", e.getMessage());
    }

    @Test
    void testValidUsernameMaxLength(){
        String username = "Longestusernameever";

        Exception e = assertThrows(IllegalArgumentException.class,
                ()->userInputValidator.validateUsernameMaxLength(username), "Username is less than 10 characters long");

        assertEquals("Username length must be 10 characters maximum.", e.getMessage());
    }

    @Test
    void testValidateUsernameNotNull(){
        String username = " ";

        Exception e = assertThrows(IllegalArgumentException.class,
                ()-> userInputValidator.validateUsernameNotNull(username), "Username is not null.");

        assertEquals("Username should not be null.", e.getMessage());
    }

    @Test
    void testValidateUsernameDatatype(){
        String username = "Securepass#";

        Exception e = assertThrows(IllegalArgumentException.class,
                ()-> userInputValidator.validateUsernameDatatype(username), "Username datatype correct, doesn't have a symbol");

        assertEquals("Username should not have symbols.", e.getMessage());
    }
}