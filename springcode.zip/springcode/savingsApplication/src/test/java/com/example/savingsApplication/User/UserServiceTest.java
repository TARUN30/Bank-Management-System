package com.example.savingsApplication.User;

import com.example.savingsApplication.Account.Account;
import com.example.savingsApplication.Account.AccountRepo;
import com.example.savingsApplication.UserInputValidator;
import com.example.savingsApplication.config.JwtService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class UserServiceTest{

    @Mock
    UserRepo userRepo;

    @Mock
    UserInputValidator userInputValidator;

    @Mock
    PasswordEncoder passwordEncoder;

    @Mock
    AccountRepo accountRepo;
    @Mock
    JwtService jwtService;
    @Mock
    AuthenticationManager authenticationManager;
    @InjectMocks
    UserService userService;
    @BeforeEach
    public void setup(){
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testCreateUser() {
        UserDTO userDTO = UserDTO.builder()
                .username("Username")
                .email("validEmail@gmail.com")
                .password("Securepass1@")
                .build();
        User user = User.builder()
                .username("Username")
                .email("validEmail@gmail.com")
                .password("Securepass1@")
                .build();

        Account account = Account.builder()
                .accountNumber(1234567890L)
                .goals(Set.of())
                .createdOn(LocalDateTime.now())
                .build();
        user.setAccount(account);
        account.setUser(user);
        when(accountRepo.save(any(Account.class))).thenReturn(account);
        when(userRepo.save(any(User.class))).thenReturn(user);        // Act & Assert (No exception should be thrown)
        UserResponseDTO userResponseDTO = userService.createUser(userDTO);

        assertEquals(userDTO.getUsername(), userResponseDTO.getUsername());
        assertEquals(userDTO.getEmail(), userResponseDTO.getEmail());
        assertNotNull(userResponseDTO.getAccountNumber());

         //Verify methods were called
        verify(userInputValidator).validateEmailLength(userDTO.getEmail());
        verify(userInputValidator).validateEmailUnique(userDTO.getEmail());
        verify(userInputValidator).validateEmailNotNull(userDTO.getEmail());
        verify(userInputValidator).validateUsernameNotNull(userDTO.getUsername());
        verify(userInputValidator).validateUsernameUnique(userDTO.getUsername());
        verify(userInputValidator).validateUsernameMinLength(userDTO.getUsername());
        verify(userInputValidator).validateUsernameDatatype(userDTO.getUsername());
        verify(userInputValidator).validateUsernameMaxLength(userDTO.getUsername());
        verify(userInputValidator).validateSymbolInPassword(userDTO.getPassword());
        verify(userInputValidator).validatePasswordMaxLength(userDTO.getPassword());
        verify(userInputValidator).validatePasswordMinLength(userDTO.getPassword());
        verify(userInputValidator).validateUppercaseLetterInPassword(userDTO.getPassword());
        verify(userInputValidator).validatePasswordNotNull(userDTO.getPassword());
        verify(userInputValidator).validateNumberInPassword(userDTO.getPassword());
        verify(userRepo).save(any());
        verify(accountRepo, times(1)).save(any(Account.class));
    }

    /**
     * Test for retrieving a user by email.
     */
    @Test
    void testGetUserByEmail_ShouldReturnUserDTO() {
        User user = User.builder()
                .username("john_doe")
                .email("johnexample.com")
                .build();

        when(userRepo.findByEmail(user.getEmail())).thenReturn(Optional.of(user));

        UserResponseDTO userResponseDTO = userService.getUser(user.getEmail());

        assertEquals(user.getEmail(), userResponseDTO.getEmail());
        assertEquals(user.getUsername(), userResponseDTO.getUsername());

        verify(userRepo, times(1)).findByEmail(user.getEmail());
    }

    /**
     * Test for retrieving a user by username.
     */
    @Test
    void testGetUserByUsername_ShouldReturnUserDTO() {
        User user = User.builder()
                .username("john_doe")
                .email("johnexample.com")
                .build();

        when(userRepo.findByEmail(user.getUsername())).thenReturn(Optional.of(user));

        UserResponseDTO userResponseDTO = userService.getUser(user.getUsername());

        assertEquals(user.getUsername(), userResponseDTO.getUsername());
        assertEquals(user.getEmail(), userResponseDTO.getEmail());

        verify(userRepo, times(1)).findByUsername(user.getUsername());
    }

    /**
     * Test for user not found exception.
     */
    @Test
    public void testUsernameNotFoundExceptionWhenUserIsEmpty(){
//        User user = User.builder()
//                .username("john_doe")
//                .email("john@example.com")
//                .build();

        when(userRepo.findByUsername(anyString())).thenReturn(Optional.empty());

        Exception e = assertThrows(UsernameNotFoundException.class,
                ()-> userService.getUser(anyString()));

        assertEquals("User not found.", e.getMessage());

        verify(userRepo).findByUsername(anyString());
    }

    @Test
    public void testGetUsers_ShouldReturnUserDTOList() {
        // Arrange: Create mock user data
        User user1 = User.builder()
                .username("john_doe")
                .email("john@example.com")
                .build();
        User user2 = User.builder()
                .username("jane_doe")
                .email("jane@example.com")
                .build();

        when(userRepo.findAll()).thenReturn(Arrays.asList(user1, user2)); // Mock database call

        // Act: Call the method
        List<UserResponseDTO> result = userService.getUsers();

        assertEquals("john_doe", result.get(0).getUsername());
        assertEquals("john@example.com", result.get(0).getEmail());

        assertEquals("jane_doe", result.get(1).getUsername());
        assertEquals("jane@example.com", result.get(1).getEmail());

        verify(userRepo, times(1)).findAll();
    }
    @Test
    void testGetUsers_ShouldReturnEmptyList_WhenNoUsers() {
        // Arrange: Mock empty database
        when(userRepo.findAll()).thenReturn(List.of());

        // Act: Call the method
        List<UserResponseDTO> result = userService.getUsers();

        // Assert: Should return an empty list
        assertNotNull(result);
        assertTrue(result.isEmpty());

        verify(userRepo, times(1)).findAll(); // Ensure findAll() was called once
    }

    @Test
    void login_ValidCredentials_ReturnsToken() {
        UserDTO userDTO = UserDTO.builder()
                .username("username")
                .email("username@gmail.com")
                .build();

        User user= User.builder()
                .username("username")
                .email("username@gmail.com")
                .build();

        when(userRepo.findByUsername(userDTO.getUsername())).thenReturn(Optional.of(user));
        when(jwtService.generateToken(user)).thenReturn("mocked-jwt-token");

        // Act
        UserResponseDTO response = userService.login(userDTO);

        // Assert
        assertEquals("mocked-jwt-token", response.getToken());

        // Verify authentication was called
        verify(authenticationManager).authenticate(
                new UsernamePasswordAuthenticationToken(userDTO.getUsername(), userDTO.getPassword()));

        // Verify user lookup and token generation
        verify(userRepo).findByUsername(userDTO.getUsername());
        verify(jwtService).generateToken(user);
    }

    @Test
    void login_InvalidCredentials_ThrowsException() {
        UserDTO userDTO = UserDTO.builder()
                .username("username")
                .email("username@gmail.com")
                .build();
        // Arrange
        doThrow(new AuthenticationException("Invalid credentials") {})
                .when(authenticationManager).authenticate(any(UsernamePasswordAuthenticationToken.class));

        // Act & Assert
        RuntimeException exception = assertThrows(RuntimeException.class, () -> userService.login(userDTO));
        assertEquals("Invalid credentials.", exception.getMessage());

        // Verify authentication attempt
        verify(authenticationManager).authenticate(any(UsernamePasswordAuthenticationToken.class));

        // Ensure user lookup and token generation were NOT called
        verifyNoInteractions(userRepo);
        verifyNoInteractions(jwtService);
    }

    @Test
    void login_UserNotFound_ThrowsException() {
        UserDTO userDTO = UserDTO.builder()
                .username("username")
                .email("username@gmail.com")
                .build();
        // Arrange
        when(userRepo.findByUsername(userDTO.getUsername())).thenReturn(Optional.empty());

        // Act & Assert
        Exception exception = assertThrows(RuntimeException.class,
                () -> userService.login(userDTO));
        assertEquals("Invalid credentials.", exception.getMessage());


        // Verify user lookup was called
        verify(userRepo).findByUsername(userDTO.getUsername());

        // Ensure token generation was NOT called
        verifyNoInteractions(jwtService);
    }

    /**
     * Test for retrieving all users.
     */
    @Test
    void testGetAllUsers() {
       User user1 = User.builder()
                .username("john_doe")
                .email("john@example.com")
                .build();

        User user2 = User.builder()
                .username("jane_doe")
                .email("jane@example.com")
                .build();
        when(userRepo.findAll()).thenReturn(Arrays.asList(user1, user2));

        List<UserResponseDTO> users = userService.getUsers();


        assertEquals("john_doe", users.get(0).getUsername());
        assertEquals("jane_doe", users.get(1).getUsername());
    }

    /**
     * Test for generating a 10-digit number.
     */
    @Test
    void testGenerate10DigitNumber() throws Exception {

        long number = userService.generate10DigitNumber();

        assertTrue(number >= 1_000_000_000L && number < 10_000_000_000L);
    }

    /**
     * Test for getString method.
     */
    @Test
    void testGetString() {
        String result = userService.getString();
        assertEquals("String theory", result);
    }

}