package com.example.savingsApplication;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class EntityResponse<T> {
    private String message;
    private T entity;
    private Integer statusCode;
}
