package com.example.savingsApplication.Goal;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface GoalRepo extends JpaRepository<Goal, Long> {

    Optional<Goal> findByGoalName(String goalName);

//    @Query("SELECT g FROM Goal g WHERE g.account_id = :accountId")
//    List<Goal> findAllByAccountId(@Param("accountId") Long accountId);

    List<Goal> findByAccount_Id(Long accountId);
    Page<Goal> findByAccount_Id(Long accountNumber, Pageable pageable);

}
