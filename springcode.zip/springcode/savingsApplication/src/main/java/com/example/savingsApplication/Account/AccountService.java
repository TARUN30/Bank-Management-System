package com.example.savingsApplication.Account;

import lombok.RequiredArgsConstructor;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AccountService {

    private final AccountRepo accountRepo;

    /**
     * Retrieves an account by its account number.
     *
     * @param accountNumber the unique account number
     * @return {@link AccountResponse} containing account details
     * @throws IllegalArgumentException if the account is not found
     */
    public AccountResponse getAccount(Long accountNumber) {
        if(accountNumber == null){
            throw new IllegalArgumentException("Account Number should not be null");
        }
        if(accountNumber.toString().length()<10){
            throw new IllegalArgumentException("Account Number should have more than 10 digits");
        }
        return accountRepo.findByAccountNumber(accountNumber)
                .map(account -> AccountResponse.builder()
                        .accountNumber(account.getAccountNumber())
                        .balance(account.getBalance())
                        .createdOn(account.getCreatedOn())
                        .build())
                .orElseThrow(() -> new IllegalArgumentException("Account not found."));
    }
    /**
     * Retrieves a list of all accounts in the system.
     *
     * @return a list of {@link AccountResponse} objects representing all accounts.
     */
    public List<AccountResponse> getAllAccounts() {
        return accountRepo.findAll()
                .stream()
                .map(account -> AccountResponse.builder()
                        .accountNumber(account.getAccountNumber())
                        .balance(account.getBalance())
                        .createdOn(account.getCreatedOn())
                        .build())
                .collect(Collectors.toList());
    }



}
