package com.example.savingsApplication;

import com.example.savingsApplication.User.UserRepo;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.regex.Pattern;

@Service
@RequiredArgsConstructor
public class UserInputValidator {


    private final UserRepo userRepo;
    public void validateEmailUnique(String email){
        boolean uniqueEmail = userRepo.existsByEmail(email);
        if(uniqueEmail){
            throw new IllegalStateException("Email already exists");
        }
    }

    public void validateEmailNotNull(String email) {
        if (email == null || email.trim().isEmpty()) {
            throw new IllegalArgumentException("Email should not be null or empty");
        }
    }

    public void validateEmailLength(String email ) {
        int maxLength = 30;
        if (email.length() > maxLength) {
            throw new IllegalArgumentException("Email should not exceed " + maxLength + " characters.");
        }
    }

    public boolean isValidEmail(String email) {
        final String EMAIL_REGEX = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$";
        final Pattern pattern = Pattern.compile(EMAIL_REGEX);

        if (email == null) {
            return false; // Null check
        }
        return pattern.matcher(email).matches();
    }

    public void validatePasswordMinLength(String password){
        final int minLength = 8;
        if(password.length()< minLength){
            throw new IllegalArgumentException("Password should not be less than 8 characters.");
        }
    }

    public void validatePasswordMaxLength(String password){
        final int maxLength = 15;
        if(password.length()> maxLength){
            throw new IllegalArgumentException("Password should not exceed 15 characters.");
        }
    }

    public void validatePasswordNotNull(String password) {
        if(password == null || password.trim().isEmpty() ){
            throw new IllegalArgumentException("Password should not be null.");
        }
    }

    public void validateSymbolInPassword(String password) {
        if(!password.matches(".*[^a-zA-Z0-9].*")){
            throw new IllegalArgumentException("Password should have atleast one symbol.");
        }
    }

    public void validateUppercaseLetterInPassword(String password){
        if(!password.matches(".*[A-Z].*")){
            throw new IllegalArgumentException("Password should have atleast one uppercase letter.");
        };
    }

    public void validateNumberInPassword(String password){
        if(!password.matches(".*\\d.*")){
            throw new IllegalArgumentException("Password should have atleast one number.");
        }
    }

    public void validateUsernameUnique(String username) {
        if(userRepo.existsByUsername(username)){
            throw new IllegalArgumentException("Username already exists.");
        }
    }

    public void validateUsernameMinLength(String username) {
        final int minLength = 5;

        if(username.length() < minLength){
            throw new IllegalArgumentException("Username length must be 5 characters minimum.");
        }
    }

    public void validateUsernameMaxLength(String username) {
        final int maxLength = 10;

        if(username.length() > 10){
            throw new IllegalArgumentException("Username length must be 10 characters maximum.");
        }
    }
    public void validateUsernameDatatype(String username){
        if(username.matches(".*[^a-zA-Z0-9].*")){
            throw new IllegalArgumentException("Username should not have symbols.");
        }
    }

    public void validateUsernameNotNull(String username) {
        if(username == null || username.trim().isEmpty()){
            throw new IllegalArgumentException("Username should not be null.");
        }
    }


}
