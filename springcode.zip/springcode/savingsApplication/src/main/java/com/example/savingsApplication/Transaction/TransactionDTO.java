package com.example.savingsApplication.Transaction;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TransactionDTO {

    private TranType tranType;

    private double amount;

    private LocalDateTime createdOn;

    private String goalName;
}
