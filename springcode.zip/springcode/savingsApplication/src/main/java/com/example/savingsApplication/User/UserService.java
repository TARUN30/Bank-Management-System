package com.example.savingsApplication.User;

//import com.example.savingsApplication.Account.Account;
//import com.example.savingsApplication.Account.AccountRepo;
import com.example.savingsApplication.Account.Account;
import com.example.savingsApplication.Account.AccountRepo;
import com.example.savingsApplication.UserInputValidator;
import com.example.savingsApplication.config.JwtService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class UserService {
    private final UserRepo userRepo;

    private final PasswordEncoder passwordEncoder;

    private final JwtService jwtService;

    private final AccountRepo accountRepo;

    private final AuthenticationManager authenticationManager;

    private final UserInputValidator userInputValidator;

    /**
     * Creates a new user after validating input fields and encoding the password.
     *
     * @param userDTO Contains user registration details (email, username, password).
     * @return UserResponseDTO containing created user details and JWT token.
     * @throws IllegalArgumentException if any input validation fails.
     */
    public UserResponseDTO createUser(UserDTO userDTO){
//UserInputValidator provides methods to validates the userDTO variables.
        userInputValidator.validateEmailUnique(userDTO.getEmail());
        userInputValidator.validateEmailLength(userDTO.getEmail());
        userInputValidator.validateEmailNotNull(userDTO.getEmail());
        userInputValidator.validateUppercaseLetterInPassword(userDTO.getPassword());
        userInputValidator.validateNumberInPassword(userDTO.getPassword());
        userInputValidator.validateSymbolInPassword(userDTO.getPassword());
        userInputValidator.validatePasswordMinLength(userDTO.getPassword());
        userInputValidator.validatePasswordMaxLength(userDTO.getPassword());
        userInputValidator.validateUsernameDatatype(userDTO.getUsername());
        userInputValidator.validateUsernameMaxLength(userDTO.getUsername());
        userInputValidator.validateUsernameMinLength(userDTO.getUsername());
        userInputValidator.validateUsernameUnique(userDTO.getUsername());
        userInputValidator.validateUsernameNotNull(userDTO.getUsername());
        userInputValidator.validatePasswordNotNull(userDTO.getPassword());

        User user = User.builder()
                .email(userDTO.getEmail())
                .username(userDTO.getUsername())
                .role(Role.CUSTOMER)
                .password(passwordEncoder.encode(userDTO.getPassword()))
                .build();
        Long accountId = generate10DigitNumber();
        Account account = Account.builder()
                .accountNumber(accountId)
                .createdOn(LocalDateTime.now())
                .build();
        user.setAccount(account);
        account.setUser(user);
       User createdUser = userRepo.save(user);
        Account savedAccount = accountRepo.save(account);
        String jwtToken = jwtService.generateToken(createdUser);
        return UserResponseDTO.builder()
                .username(createdUser.getUsername())
                .email(createdUser.getEmail())
                .token(jwtToken)
                .accountNumber(accountId)
                .build();
    }

    /**
     * Authenticates a user and generates a JWT token upon successful login.
     *
     * @param userDTO Contains login credentials (username, password).
     * @return UserResponseDTO containing a JWT token.
     * @throws AuthenticationException if authentication fails due to invalid credentials.
     */
    public UserResponseDTO login(UserDTO userDTO) {
        try {
            authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(
                    userDTO.getUsername(),
                    userDTO.getPassword()
            ));
            var user = userRepo.findByUsername(userDTO.getUsername())
                    .orElseThrow(() -> new UsernameNotFoundException("User not found."));
            String jwtToken = jwtService.generateToken(user);
            return UserResponseDTO.builder()
                    .accountNumber(user.getAccount().getAccountNumber())
                    .token(jwtToken)
                    .build();
        } catch (AuthenticationException e) {
            throw new RuntimeException("Invalid credentials.");
        }
    }

    /**
     * Retrieves a user by username or email.
     *
     * @param identifier The username or email of the user.
     * @return A {@link UserResponseDTO} containing the user's details.
     * @throws UsernameNotFoundException if the user is not found.
     */
    public UserResponseDTO getUser(String identifier) {
        return userRepo.findByUsername(identifier)
                .or(() -> userRepo.findByEmail(identifier))
                .map(user -> UserResponseDTO.builder()
                        .username(user.getUsername())
                        .email(user.getEmail())
                        .accountNumber(user.getAccount().getAccountNumber())
                        .build())
                .orElseThrow(() -> new UsernameNotFoundException("User not found."));
    }

    /**
     * Retrieves a list of all users.
     *
     * @return A list of {@link UserResponseDTO} containing user details.
     */
    public List<UserResponseDTO> getUsers() {
        return userRepo.findAll().stream()
                .map(user -> UserResponseDTO.builder()
                        .email(user.getEmail())
                        .username(user.getUsername())
                        .build())
                .collect(Collectors.toList());
    }

    /**
     * Generates a random 10-digit number.
     *
     * @return A randomly generated 10-digit number.
     */
    public long generate10DigitNumber() {
        Random random = new Random();
        return 1_000_000_000L + random.nextLong(9_000_000_000L);
    }

    /**
     * Sample API endpoint that returns a static string response.
     *
     * @return A string message "String theory".
     */
    @GetMapping("string")
    public String getString() {
        System.out.println("I hate my life");
        return "String theory";
    }
}

