package com.example.savingsApplication.User;

public enum Role{

    ADMIN,
    CUSTOMER
}
