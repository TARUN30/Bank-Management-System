package com.example.savingsApplication.Transaction;

import com.example.savingsApplication.Account.Account;
import com.example.savingsApplication.Account.AccountRepo;
import com.example.savingsApplication.Goal.Goal;
import com.example.savingsApplication.Goal.GoalRepo;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Service class for handling transactions related to saving goals.
 */
@Service
@RequiredArgsConstructor
public class TransactionService {

    private final TransactionRepo transactionRepo;
    private final AccountRepo accountRepo;
    private final GoalRepo goalRepo;

    /**
     * Deposits a specified amount into a goal.
     *
     * @param transactionDTO the transaction details including goal name and amount
     * @return the saved transaction
     * @throws IllegalArgumentException if the goal is not found
     */
    @Transactional
    public Transaction deposit(TransactionDTO transactionDTO) {
        double newAmount = 0;

        if(transactionDTO == null){
            throw new IllegalArgumentException("TransactionDTO(deposit) should not be null.");
        }
        if(transactionDTO.getGoalName().isEmpty()){
            throw new IllegalArgumentException("Goal Name in TransactionDTO should not be null.");
        }

        Goal goal = goalRepo.findByGoalName(transactionDTO.getGoalName())
                .orElseThrow(() -> new IllegalArgumentException("Goal not found."));
        Account account = accountRepo.findByAccountNumber(goal.getAccount().getAccountNumber())
                .orElseThrow(() -> new IllegalArgumentException("Account not found."));

        if (transactionDTO.getTranType() == TranType.DEPOSIT) {
            newAmount = goal.getSavedAmount() + transactionDTO.getAmount();
            double actBal = account.getBalance() + transactionDTO.getAmount();
            account.setBalance(actBal);
            goal.setSavedAmount(newAmount);
            goal.setAccount(account);
        }

        Transaction transaction = Transaction.builder()
                .amount(newAmount)
                .createdOn(LocalDateTime.now())
                .tranType(TranType.DEPOSIT)
                .goal(goal)
                .build();

        return transactionRepo.save(transaction);
    }

    /**
     * Withdraws a specified amount from a goal if the balance is sufficient.
     *
     * @param transactionDTO the transaction details including goal name and amount
     * @return the saved transaction
     * @throws IllegalArgumentException if the goal is not found
     */
    @Transactional
    public Transaction withdraw(TransactionDTO transactionDTO) {
        double amount = 0;

        if(transactionDTO == null){
            throw new IllegalArgumentException("TransactionDTO(withdrawal) should not be null.");
        }
        if(transactionDTO.getGoalName().isEmpty()){
            throw new IllegalArgumentException("Goal Name in TransactionDTO should not be null.");
        }

        Goal goal = goalRepo.findByGoalName(transactionDTO.getGoalName())
                .orElseThrow(() -> new IllegalArgumentException("Goal not found"));
        Account account = accountRepo.findByAccountNumber(goal.getAccount().getAccountNumber())
                .orElseThrow(() -> new IllegalArgumentException("Account not found."));

        if (transactionDTO.getTranType() == TranType.WITHDRAW) {
            if (goal.getSavedAmount() >= transactionDTO.getAmount()) {
                amount = goal.getSavedAmount() - transactionDTO.getAmount();
                double actBal = account.getBalance() - transactionDTO.getAmount();
                account.setBalance(actBal);
                goal.setSavedAmount(amount);
                goal.setAccount(account);
            } else {
                throw new IllegalArgumentException("Insufficient saved amount for withdrawal.");
            }
        }

        Transaction transaction = Transaction.builder()
                .amount(amount)
                .createdOn(LocalDateTime.now())
                .tranType(TranType.WITHDRAW)
                .goal(goal)
                .build();

        return transactionRepo.save(transaction);
    }

    /**
     * Retrieves all transactions associated with a specific goal.
     *
     * @param goalName the name of the goal
     * @return a list of transactions related to the specified goal
     */
    public List<Transaction> getAllTransactions(String goalName) {
        if(goalName == null){
            throw new IllegalArgumentException("Goal Name should not be null");
        }
        return transactionRepo.findAll()
                .stream()
                .filter(transaction -> transaction.getGoal() != null &&
                        transaction.getGoal().getGoalName().equals(goalName))
                .collect(Collectors.toList());
    }
}
