package com.example.savingsApplication.Goal;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class GoalDTO {
    private Long accountNumber;
    private String goalName;

    private double targetAmount;


    private LocalDateTime period;
}
