package com.example.savingsApplication.Transaction;

public enum TranType {

    DEPOSIT,

    WITHDRAW
}
