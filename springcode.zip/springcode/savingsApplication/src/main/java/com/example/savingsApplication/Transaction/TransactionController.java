package com.example.savingsApplication.Transaction;

import com.example.savingsApplication.EntityResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping("api/v1/transactions")
@RequiredArgsConstructor
@RestController
public class TransactionController {
    private final TransactionService transactionService;

    @PostMapping("deposit")
    public EntityResponse<?> deposit(@RequestBody TransactionDTO transactionDTO){
        Transaction transaction = transactionService.deposit(transactionDTO);

        return EntityResponse.builder()
                .message("Deposit successful.")
                .entity(transaction)
                .statusCode(HttpStatus.OK.value())
                .build();
    }

    @PostMapping("withdrawal")
    public EntityResponse<?> withdrawal(@RequestBody TransactionDTO transactionDTO){
        Transaction transaction = transactionService.withdraw(transactionDTO);

        return EntityResponse.builder()
                .message("Deposit successful.")
                .entity(transaction)
                .statusCode(HttpStatus.OK.value())
                .build();
    }

    @GetMapping("getTransactions")
    public EntityResponse<?> getTransactionByGoalName(@RequestParam String goalName){
        List<Transaction> transactions = transactionService.getAllTransactions(goalName);

        return EntityResponse.builder()
                .message("List of transactions retrieved successfully.")
                .statusCode(HttpStatus.OK.value())
                .entity(transactions)
                .build();
    }
}
