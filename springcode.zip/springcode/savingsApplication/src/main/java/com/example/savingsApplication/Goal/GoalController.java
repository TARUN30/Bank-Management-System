package com.example.savingsApplication.Goal;

import com.example.savingsApplication.EntityResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequiredArgsConstructor
@RequestMapping("api/v1/goals")
@RestController
public class GoalController {
    private final GoalService goalService;

    @PostMapping("createGoal")
    public EntityResponse<?> createGoal(@RequestBody GoalDTO goalDTO){
        GoalResponse goalResponse = goalService.createGoal(goalDTO);

        return EntityResponse.builder()
                .message("Goal created successfully")
                .statusCode(HttpStatus.CREATED.value())
                .entity(goalResponse)
                .build();
    }
    @GetMapping("getGoalByGoalname")
    public EntityResponse<?> getGoalByGoalName(@RequestParam String goalName){
        Goal goal = goalService.getGoal(goalName);

        return EntityResponse.builder()
                .message("Goal retrieved successfully")
                .entity(goal)
                .statusCode(HttpStatus.FOUND.value())
                .build();
    }
    @GetMapping("/getGoals")
    public EntityResponse<?> getGoalsByGoalName(@RequestParam Long accountId){
        List<GoalResponse> goalResponseList = goalService.getGoalList(accountId);

        return EntityResponse.builder()
                .message("List of goals retrieved successfully")
                .entity(goalResponseList)
                .statusCode(HttpStatus.FOUND.value())
                .build();
    }

    @DeleteMapping("deleteGoal")
    public EntityResponse<?> deleteGoal(String goalName){
        goalService.delete(goalName);

        return EntityResponse.builder()
                .message("Goal deleted successfully")
                .statusCode(HttpStatus.OK.value())
                .entity(null)
                .build();
    }

    @GetMapping("/getGoalsPaginated")
    public EntityResponse<?> getGoalsByAccountNumber(
            @RequestParam Long accountNumber,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {

        Page<Goal> goals = goalService.findByAccountNumber(accountNumber, PageRequest.of(page, size));
        return EntityResponse.builder()
                .message("List of goals retrieved successfully")
                .statusCode(HttpStatus.OK.value())
                .entity(goals)
                .build();
    }
}
