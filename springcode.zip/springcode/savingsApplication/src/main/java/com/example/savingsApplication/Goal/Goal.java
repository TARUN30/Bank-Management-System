package com.example.savingsApplication.Goal;

import com.example.savingsApplication.Account.Account;
import com.example.savingsApplication.Transaction.Transaction;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

import static jakarta.persistence.FetchType.LAZY;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class Goal {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @EqualsAndHashCode.Include
    private Long id;

    @Column(unique = true)
    private String goalName;

    private double targetAmount;

    private double savedAmount;

    private LocalDateTime period;

    private boolean deleteFlag;


    @CreatedDate
    private LocalDateTime createdOn;
    @EqualsAndHashCode.Exclude
    @ManyToOne(cascade = CascadeType.ALL,fetch= LAZY)
    @JoinColumn(name = "account_id") // Foreign Key in Goal table
    private Account account;

    @OneToMany(mappedBy="goal",cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<Transaction> transactions = new HashSet<Transaction>();
}
