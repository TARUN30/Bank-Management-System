package com.example.savingsApplication.Goal;

import com.example.savingsApplication.Account.Account;
import com.example.savingsApplication.Account.AccountRepo;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Service class for managing financial goals associated with accounts.
 */
@Service
@RequiredArgsConstructor
public class GoalService {

    private final GoalRepo goalRepo;
    private final AccountRepo accountRepo;

    /**
     * Creates a new financial goal for a given account.
     *
     * @param goalDTO the data transfer object containing goal details
     * @return {@link GoalResponse} representing the created goal
     * @throws IllegalArgumentException if the associated account is not found
     */
    public GoalResponse createGoal(GoalDTO goalDTO) {
        if(goalDTO == null){
            throw new IllegalArgumentException("GoalDTO should not be null");
        }

        Account account = accountRepo.findByAccountNumber(goalDTO.getAccountNumber())
                .orElseThrow(() -> new IllegalArgumentException("Account not found."));

        Goal goal = Goal.builder()
                .goalName(goalDTO.getGoalName())
                .targetAmount(goalDTO.getTargetAmount())
                .period(goalDTO.getPeriod())
                .build();
        goal.setAccount(account);
        if(account.getGoals().isEmpty()){

            account.setGoals(new HashSet<>());
        }

           account.getGoals().add(goal);

        accountRepo.save(account);
        //Goal goalSaved = goalRepo.save(goal);

        return GoalResponse.builder()
                .goalName(goal.getGoalName())
                .period(goal.getPeriod())
                .targetAmount(goal.getTargetAmount())
                .build();
    }

    /**
     * Retrieves a specific goal by its name.
     *
     * @param goalName the name of the goal
     * @return {@link Goal} object representing the goal
     * @throws IllegalArgumentException if the goal does not exist
     */
    public Goal getGoal(String goalName) {
        if(goalName == null){
            throw new IllegalArgumentException("Goal Name should not be null");
        }
        return goalRepo.findByGoalName(goalName)
                .orElseThrow(() -> new IllegalArgumentException("Goal does not exist"));
    }

    /**
     * Retrieves a list of goals by their name.
     *
     * @param accountNumber the name of the goals to retrieve
     * @return a list of {@link GoalResponse} objects representing the goals
     */
    public List<GoalResponse> getGoalList(Long accountNumber) {
        if(accountNumber == null){
            throw new IllegalArgumentException("Account Number should not be null");
        }
        if(accountNumber.toString().length()<10){
            throw new IllegalArgumentException("Account Number should have more than 10 digits");
        }

        Account account = accountRepo.findByAccountNumber(accountNumber)
                .orElseThrow(() ->new IllegalArgumentException("Account not found."));
        return goalRepo.findByAccount_Id(account.getId())
                .stream()
                .map(goal -> GoalResponse.builder()
                        .targetAmount(goal.getTargetAmount())
                        .savedAmount(goal.getSavedAmount())
                        .goalName(goal.getGoalName())
                        .period(goal.getPeriod())
                        .build())
                .collect(Collectors.toList());
    }

    /**
     * Marks a goal as deleted by setting the delete flag to true.
     *
     * @param goalName the name of the goal to delete
     * @throws IllegalArgumentException if the goal is not found
     */
    public void delete(String goalName) {
        if(goalName == null){
            throw new IllegalArgumentException("Goal Name should not be null");
        }
        Goal goal = goalRepo.findByGoalName(goalName)
                .orElseThrow(() -> new IllegalArgumentException("Goal not found"));

        goal.setDeleteFlag(true);
        goalRepo.save(goal);
    }





    /**
     * Retrieves a paginated list of goals associated with a specific account number.
     *
     * @param accountNumber The account number for which goals are being retrieved. Must not be null
     *                      and should contain more than 10 digits.
     * @param pageable The pagination information including page number and page size. Must not be null.
     * @return A paginated list of goals associated with the given account number.
     * @throws IllegalArgumentException If the account number is null, has fewer than 10 digits,
     *                                  if the pageable object is null, or if the account is not found.
     */
    public Page<Goal> findByAccountNumber(Long accountNumber, Pageable pageable) {
        if (accountNumber == null) {
            throw new IllegalArgumentException("Account Number should not be null");
        }
        if (accountNumber.toString().length() < 10) {
            throw new IllegalArgumentException("Account Number should have more than 10 digits");
        }
        if (pageable == null) {
            throw new IllegalArgumentException("Pageable (page number and page size) should not be null");
        }

        Account account = accountRepo.findByAccountNumber(accountNumber)
                .orElseThrow(() -> new IllegalArgumentException("Account not found."));
        return goalRepo.findByAccount_Id(account.getId(), pageable);
    }

    /**
     * Updates an existing financial goal with new details provided in the GoalDTO.
     *
     * @param goalDTO The Goal Data Transfer Object containing updated goal details. Must not be null.
     * @return The updated Goal entity after saving changes.
     * @throws IllegalArgumentException If the GoalDTO is null or if the goal specified in the DTO
     *                                  does not exist.
     */
    public Goal updateGoal(GoalDTO goalDTO) {
        if (goalDTO == null) {
            throw new IllegalArgumentException("GoalDTO should not be null");
        }

        Goal goal = goalRepo.findByGoalName(goalDTO.getGoalName())
                .orElseThrow(() -> new IllegalArgumentException("Goal not found"));

        goal.setTargetAmount(goalDTO.getTargetAmount());

        return goalRepo.save(goal);
    }

}
