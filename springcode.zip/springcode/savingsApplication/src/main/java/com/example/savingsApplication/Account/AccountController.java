package com.example.savingsApplication.Account;

import com.example.savingsApplication.EntityResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("api/v1/accounts")
@RequiredArgsConstructor
public class AccountController {
    private final AccountService accountService;

    @GetMapping("getAccount")
    public AccountResponse getAccount(@RequestParam Long accountNumber){
        AccountResponse accountResponse = accountService.getAccount(accountNumber);
    return accountResponse;
//        return EntityResponse.builder()
//                .message("Account retrieved successfully.")
//                .entity(accountResponse)
//                .statusCode(HttpStatus.FOUND.value())
//                .build();
    }

}

