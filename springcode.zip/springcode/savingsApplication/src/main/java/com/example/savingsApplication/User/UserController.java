package com.example.savingsApplication.User;

import com.example.savingsApplication.EntityResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("api/v1/users")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping("register")
    public EntityResponse<?> createUser(@RequestBody UserDTO userDTO){
        try{
        UserResponseDTO userResponseDTO = userService.createUser(userDTO);
        EntityResponse<UserResponseDTO> res = EntityResponse.<UserResponseDTO>builder()
                .entity(userResponseDTO)
                .message("User Created Successfully")
                .statusCode(HttpStatus.CREATED.value())
                .build();
        return res;
    }
        catch(Exception e){
            EntityResponse<UserResponseDTO> res = EntityResponse.<UserResponseDTO>builder()
                    .entity(null)
                    .message(e.getMessage())
                    .statusCode(HttpStatus.BAD_REQUEST.value())
                    .build();
            return res;
    }}

    @PostMapping("login")
    public EntityResponse<?> login(@RequestBody UserDTO userDTO){
        UserResponseDTO userResponseDTO = userService.login(userDTO);
        EntityResponse<UserResponseDTO> res = EntityResponse.<UserResponseDTO>builder()
                .entity(userResponseDTO)
                .message("User authenticated Successfully")
                .statusCode(HttpStatus.CREATED.value())
                .build();
        return res;
    }

    @GetMapping("/getUser")
    public EntityResponse<?> getUser(@RequestParam String id){
        UserResponseDTO userResponseDTO = userService.getUser(id);
        return EntityResponse.builder()
                .entity(userResponseDTO)
                .message("User retrieved successful.")
                .statusCode(HttpStatus.FOUND.value())
                .build();
    }

    @GetMapping("string")
    public ResponseEntity<?> getString(){
        return ResponseEntity.ok("My head is an animal.");
    }
}
