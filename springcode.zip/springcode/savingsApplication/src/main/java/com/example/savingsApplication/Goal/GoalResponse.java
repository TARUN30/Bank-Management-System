package com.example.savingsApplication.Goal;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.Locale;
@Builder
@Data
public class GoalResponse {

    private String goalName;
    private double targetAmount;
    private double savedAmount;


    private LocalDateTime period;
}
